﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication4.Controllers
{
    public class HelloWorldController : Controller
    {

        public ViewResult Index(int id)
        {
            //return View("MyView");
            if (id == 1)
                return View("MyView");
            else if (id == 2)
                return View("View1");
            else
                return View("View2");
            
        }
      
         
        // GET: /HelloWorld/Welcome/ 

        public string Welcome()
        {
            return "This is the Welcome action method...";
        }
    }
}