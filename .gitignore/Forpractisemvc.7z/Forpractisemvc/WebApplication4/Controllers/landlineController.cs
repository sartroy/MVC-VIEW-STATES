﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication4.Controllers
{
    public class landlineController : Controller
    {
        // GET: landline
        public string landline2()
        {
            return "LandLine <br/> <br/> BSNL LANDLINE <br/><br/> BSNL PCO <br/><br/> Telephone Facilities <br/><br/> IN Services";
        }
    }
}