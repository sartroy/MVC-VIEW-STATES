﻿using EmployeeMVC_Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EmployeeMVC_Project.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        public ActionResult EmployeeDetails()
        {
            IList<Employee> employeeList = new List<Employee>()
                {
                new Employee(){FirstName="Sarthak",LastName="Roy",Age=40 },
                new Employee(){FirstName="Debesh",LastName="Roy",Age=40 },
                new Employee(){FirstName="Sumendra",LastName="Roy",Age=40 },
                new Employee(){FirstName="Aditya",LastName="Roy",Age=40 }
            };

            //Employee e1 = new Employee();
            //e1.FirstName = fs;
            //e1.LastName = ls;
            //e1.Age = a;

            //ViewBag.data = employeeList;
            return View(employeeList);
        }
    }
}